# Siren License

PLEASE READ CAREFULLY THIS SIREN LICENSE AGREEMENT (THIS “AGREEMENT”), WHICH CONSTITUTES A LEGALLY BINDING AGREEMENT AND GOVERNS YOUR USE OF ALL OF THE SIREN SOFTWARE WITH WHICH THIS AGREEMENT IS INCLUDED THAT IS PROVIDED IN OBJECT CODE FORMAT, AND, IN ACCORDANCE WITH SECTION 3 BELOW, CERTAIN OF THE SIREN SOFTWARE THAT IS PROVIDED IN SOURCE CODE FORMAT.

This Agreement is entered into by and between Sindice Limited, a company incorporated in Ireland with a registered address at 3 Galway Technology Centre, Mervue Business & Technology Park, Wellpark Road, Galway (“SIREN”) and You, or the legal entity on behalf of whom You are acting (as applicable, “You”) for:

The Siren Platform or other software created by Siren which is available through the Siren website or on Siren controlled GitHub accounts (“Siren Software”); and
electronic documents (if any) (“Documents”).
Siren license use of the Siren Software and Document to You on the basis of this Agreement. Siren is not selling the Siren Software or Documents to You. Siren remains the owners of the Siren Software and Documents at all times.

## IMPORTANT NOTICE TO ALL USERS:

BY DOWNLOADING THE SOFTWARE YOU AGREE TO THE TERMS OF THIS AGREEMENT WHICH WILL BIND YOU AND YOUR EMPLOYEES. THE TERMS OF THIS LICENCE INCLUDE, IN PARTICULAR, LIMITATIONS ON LIABILITY IN SECTION 4.

IF YOU DO NOT AGREE TO THE TERMS OF THIS AGREEMENT, WE WILL NOT LICENSE THE SOFTWARE AND DOCUMENTS TO YOU AND YOU MUST DISCONTINUE THE DOWNLOADING PROCESS. IN THIS CASE YOU MAY NOT DOWNLOAD OR ORDER ANY SOFTWARE OR DOCUMENTS FROM THIS WEBSITE.

IF YOU ARE INSTALLING OR USING THE SOFTWARE ON BEHALF OF A LEGAL ENTITY, YOU REPRESENT AND WARRANT THAT YOU HAVE THE ACTUAL AUTHORITY TO AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT ON BEHALF OF SUCH ENTITY.

## 1. OBJECT CODE END USER LICENSES, RESTRICTIONS AND THIRD PARTY OPEN SOURCE SOFTWARE

1.1 Object Code End User License. Subject to the terms and conditions of  Section 1.2 of this Agreement, in consideration of you agreeing to abide by the terms of this Agreement, Siren hereby grants to You, a License to the Basic Features and Functions of the Siren Software.

1.2 Reservation of Rights; Restrictions. As between Siren and You, Siren and its licensors own all right, title and interest in and to the Siren Software, and except as expressly set forth in Sections 1.1, and 3.1 of this Agreement, no other license to the Siren Software is granted to You under this Agreement, by implication, estoppel or otherwise. You agree not to:

(1) reverse engineer or decompile, decrypt, disassemble or otherwise reduce any Siren Software provided to You in Object Code, or any portion thereof, to Source Code, except and only to the extent any such restriction is prohibited by applicable law,

(2) except as expressly permitted in this Agreement, prepare derivative works from, modify, copy or use the Siren Software Object Code or the Commercial Software Source Code in any manner;

(3) except as expressly permitted in Section 1.1 above, transfer, sell, rent, lease, distribute, sublicense, loan or otherwise transfer, Siren Software Object Code, in whole or in part, to any third party;

(4) use Siren Software Object Code for providing time-sharing services, any software-as-a-service, service bureau services or as part of an application services provider or other service offering (collectively, “SaaS Offering”) where obtaining access to the Siren Software or the features and functions of the Siren Software is a primary reason or substantial motivation for users of the SaaS Offering to access and/or use the SaaS Offering (“Prohibited SaaS Offering”);

(5) circumvent the limitations on use of Siren Software provided to You in Object Code format that are imposed or preserved by any License Key, or

(6) alter or remove any Marks and Notices in the Siren Software. If You have any question as to whether a specific SaaS Offering constitutes a Prohibited SaaS Offering, or are interested in obtaining Siren’s permission to engage in commercial or non-commercial distribution as well as customizations of the Siren Software, please contact info@siren.io.

(7) copy the Siren Software or Documents except where such copying is incidental to normal use of the Siren Software, or where it is necessary for the purpose of back-up or operational security;

1.3 Except as expressly set out in this Agreement or as permitted by any local law, you undertake to:

(1) supervise and control use of the Siren Software and ensure that the Siren Software is used by your employees and representatives in accordance with the terms of this Agreement;

(2) include our copyright notice on all entire and partial copies of the Siren Software in any form

(3) comply with all applicable technology control or export laws and regulations;

1.4 Third Party Open Source Software. The Commercial Software may contain or be provided with third party open source libraries, components, utilities and  other open source software (collectively, “Open Source Software”), which Open Source Software may have applicable license terms as identified on a website designated by Siren. Notwithstanding anything to the contrary herein, use of the Open Source Software shall be subject to the license terms and conditions applicable to such Open Source Software, to the extent required by the applicable licensor (which terms shall not restrict the license rights granted to You hereunder, but may contain additional rights). To the extent any condition of this Agreement conflicts with any license to the Open Source Software, the Open Source Software license will govern with respect to such Open Source Software only. Siren may also separately provide you with certain open source software that is licensed by Siren. Your use of such Siren open source software will not be governed by this Agreement, but by the applicable open source license terms.

## 2. INTELLECTUAL PROPERTY RIGHTS

2.1 You acknowledge that all intellectual property rights in the Siren Software and the Documents anywhere in the world belong to us, that rights in the Siren Software is licensed (not sold) to you, and that you have no rights in, or to, the Siren Software or the Documents other than the right to use them in accordance with the terms of this Agreement.

2.2 You acknowledge that your right to access the Siren Software in source code form is limited by Section 3.

## 3 COMMERCIAL SOFTWARE SOURCE CODE

3.1 Limited License. Subject to the terms and conditions of Section 3.2 of this Agreement and in consideration of you agreeing to abide by the terms of the Agreement, Siren hereby grants to You a revocable, limited, non-exclusive, non-transferable, fully paid up royalty free right and license to the Commercial Software in Source Code format, without the right to grant or authorize sublicenses, to prepare Derivative Works of the Commercial Software, provided You do not hack, alter or amend the licensing mechanism, or otherwise circumvent the intended limitations on the use of Siren Software as described at https://siren.io/siren-editions. Also you will not use the Searchguard licence provided with the Commercial Software for other purpose that is not the use of the Siren Software according to the intended limitations on the use of the Siren Software.

3.2 Restrictions. Nothing in Section 3.1 grants You the right to (i) use the Commercial Software Source Code other than in accordance with Section 3.1 above, (ii) use a Derivative Work of the Commercial Software outside of a Non-production Environment, in any production capacity, on a temporary or permanent basis, or (iii) transfer, sell, rent, lease, distribute, sublicense, loan or otherwise make available the Commercial Software Source Code, in whole or in part, to any third party. Notwithstanding the foregoing, You may maintain a copy of the repository in which the Source Code of the Commercial Software resides and that copy may be publicly accessible, provided that you include this Agreement with Your copy of the repository.

## 4. TERMINATION

4.1 Termination. We may terminate this Agreement at any time upon 14 days prior written notice to You or immediately by written notice to you if you commit a material or persistent breach of this Licence. Your licence to use the Siren Software shall terminate automatically if you breach any term of this Agreement.

4.2 Post Termination. Upon any termination of this Agreement, for any reason, You shall (i) promptly cease the use of the Siren Software in Object Code format and Source Code format and (ii) immediately delete or remove the Siren Software from all computer equipment in your possession, and immediately destroy all copies of the Siren Software and Documents then in your possession, custody or control and, certify to us that you have done so. For the avoidance of doubt, termination of this Agreement will not affect Your right to use Siren Software, in either Object Code or Source Code formats, made available under the Apache License Version 2.0.

4.3 Survival. Sections 1.2, 2, 3.2. 3.2, 5 and 6 shall survive any termination or expiration of this Agreement.

## 5. DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY

5.1 Disclaimer of Warranties. YOU ACKNOWLEDGE THAT THE SIREN SOFTWARE HAS NOT BEEN DEVELOPED TO MEET YOUR INDIVIDUAL REQUIREMENTS, AND THAT IT IS THEREFORE YOUR RESPONSIBILITY TO ENSURE THAT THE FACILITIES AND FUNCTIONS OF THE SIREN SOFTWARE AS DESCRIBED IN THE DOCUMENTS MEET YOUR REQUIREMENTS. TO THE MAXIMUM EXTENT PERMITTED UNDER APPLICABLE LAW, THE Siren SOFTWARE IS PROVIDED “AS IS” WITHOUT WARRANTY OF ANY KIND, AND SIREN AND ITS LICENSORS MAKE NO WARRANTIES WHETHER EXPRESSED, IMPLIED OR STATUTORY REGARDING OR RELATING TO THE SIREN SOFTWARE. TO THE MAXIMUM EXTENT PERMITTED UNDER APPLICABLE LAW, SIREN AND ITS LICENSORS SPECIFICALLY DISCLAIM ALL IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT WITH RESPECT TO THE SIREN SOFTWARE, AND WITH RESPECT TO THE USE OF THE FOREGOING. FURTHER, SIREN DOES NOT WARRANT RESULTS OF USE OR THAT THE SIREN SOFTWARE WILL BE ERROR FREE OR THAT THE USE OF THE
SIREN SOFTWARE WILL BE UNINTERRUPTED.

5.2 Limitation of Liability. IN NO EVENT SHALL SIREN OR ITS LICENSORS BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY INDIRECT DAMAGES, FOR ANY LOSS OF PROFITS, LOSS OF USE, BUSINESS INTERRUPTION, LOSS OF DATA, COST OF SUBSTITUTE GOODS OR SERVICES, OR FOR ANY SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES OF ANY KIND, IN CONNECTION WITH OR ARISING OUT OF THE DOCUMENTATION OR USE OR INABILITY TO USE THE SIREN SOFTWARE, OR THE PERFORMANCE OF OR FAILURE TO PERFORM THIS AGREEMENT, WHETHER ALLEGED AS A BREACH OF CONTRACT OR TORTIOUS CONDUCT, INCLUDING NEGLIGENCE, EVEN IF SIREN
HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SIREN’S MAXIMUM AGGREGATE LIABILITY UNDER OR IN CONNECTION WITH THIS AGREEMENT WHETHER IN CONTRACT, TORT (INCLUDING NEGLIGENCE) OR OTHERWISE, SHALL IN ALL CIRCUMSTANCES BE LIMITED TO A SUM EQUAL TO €1.

5.3 Nothing in this Licence shall limit or exclude Siren’s liability for: (i) death or personal injury resulting from our negligence (ii) fraud or fraudulent misrepresentation; or (iii) any other liability that cannot be excluded or limited by Irish law.

5.4 This Agreement sets out the full extent of our obligations and liabilities in respect of the supply of the Siren Software and Documents. Except as expressly stated in this Agreement, there are no conditions, warranties, representations or other terms, express or implied, that are binding on us. Any condition, warranty, representation or other term concerning the supply of the Siren Software and Documents which might otherwise be implied into, or incorporated in, this Agreement whether by statute, common law or otherwise, is excluded to the fullest extent permitted by law.

## 6. MISCELLANEOUS

6.1 This Agreement constitutes the entire agreement between us and supersedes and extinguishes all previous agreements, promises, assurances, warranties, representations and understandings between us, whether written or oral, relating to its subject matter. You agree that You shall have no remedies in respect of any statement, representation, assurance or warranty (whether made innocently or negligently) that is not set out in this Agreement. You agree that You shall have no claim for innocent or negligent misrepresentation or negligent misstatement based on any statement in this in this Agreement.

6.2 This Agreement may be modified by Siren from time to time, and any such modifications will be effective upon the “Posted Date” set forth at the top of the modified Agreement.

6.3 Each of the conditions of this Agreement operates separately. If any court or competent authority decides that any of them are unlawful or unenforceable, the remaining conditions will remain in full force and effect.

6.4 This Agreement, its subject matter and its formation (and any non-contractual disputes or claims) are governed by Irish law. Each party irrevocably agree to the exclusive jurisdiction of the Irish Courts.

6.5 A breach or threatened breach, by You of this Agreement may cause irreparable harm for which damages at law may not provide adequate relief, and therefore Siren shall be entitled to seek injunctive relief without being required to post a bond.

6.6 Siren may transfer our rights and obligations under this Agreement to another organisation, but this will not affect your rights or our obligations under this Agreement. You may not assign this Agreement (including by operation of law in connection with a merger or acquisition), in whole or in part to any third party without the prior written consent of Siren, which may be withheld or granted by Siren in its sole and absolute discretion. Any assignment in violation of the preceding sentence is void. Notices to Siren may also be sent to info@siren.io.

6.7 Any notice given by you to us, or by us to you, will be deemed received and properly served immediately when posted on our website, 24 hours after an e-mail is sent, or three days after the date of posting of any letter. In proving the service of any notice, it will be sufficient to prove, in the case of a letter, that such letter was properly addressed, stamped and placed in the post and, in the case of an e-mail, that such e-mail was sent to the specified e-mail address of the addressee.

## 7. DEFINITIONS

The following terms have the meanings ascribed:

7.1 “Affiliate” means, with respect to a party, any entity that controls, is controlled by, or which is under common control with, such party, where “control” means ownership of at least fifty percent (50%) of the outstanding voting shares of the entity, or the contractual right to establish policy for, and manage the operations of, the entity.

7.2 “Basic Features and Functions” means those features and functions of the Siren Software that are eligible for use in the Siren Community Edition, as set forth at https://siren.io/siren-editions, as may be modified by Siren from time to time.

7.3 “Commercial Software” means the Siren Software Source Code in any file repository controlled by Siren or containing a header stating the contents are subject to the Siren License, unless a LICENSE file present in the directory subtree declares a different license.

7.4 “Derivative Work of the Commercial Software” means, for purposes of this Agreement, any modification(s) or enhancement(s) to the Commercial Software, which represent, as a whole, an original work of authorship.

7.5 “License” means a limited, non-exclusive, non-transferable, fully paid up, royalty free, right and license, without the right to grant or authorize sublicenses, solely for Your internal business operations to (i) install and use the applicable Basic Features and Functions of the Siren Software in Object Code, and (ii) permit contractors and Your Affiliates to use the Siren software as set forth in (i) above, provided that such use by contractors must be solely for Your benefit and/or the benefit of Your Affiliates, and You
shall be responsible for all acts and omissions of such contractors and Affiliates in connection with their use of the Siren Software that are contrary to the terms and conditions of this Agreement.

7.6 “License Key” means a sequence of bytes, including but not limited to a JSON blob, that is used to enable certain features and functions of the Siren Software.

7.7 “Marks and Notices” means all Siren trademarks, trade names, logos and notices present on the Documentation as originally provided by SIREN.

7.8 “Non-production environment” means an environment for development, testing or quality assurance, where software is not used for production purposes.

7.9 “Object Code” means any form resulting from mechanical transformation or translation of Source Code form, including but not limited to compiled object code, generated documentation, and conversions to other media types.

7.10 “Source Code” means the preferred form of computer software for making modifications, including but not limited to software source code, documentation source, and configuration files.
